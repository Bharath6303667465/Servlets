package com.bharath;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;



@WebServlet("/servlet1")
public class HiddenFormFieldSessionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Check if the session ID is already present in the hidden form field
        String sessionId = request.getParameter("sessionId");

        if (sessionId == null || sessionId.isEmpty()) {
            // Generate a new session ID
            sessionId = java.util.UUID.randomUUID().toString();
        }

        // Set the response content type
        response.setContentType("text/html");

        // Write the session ID in the response
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Session ID: " + sessionId + "</h2>");
        out.println("<form action=\"servlet2\" method=\"post\">");
        out.println("<input type=\"hidden\" name=\"sessionId\" value=\"" + sessionId + "\">");
        out.println("<input type=\"submit\" value=\"Submit\">");
        out.println("</form>");
        out.println("</body></html>");
    }
}
