package com.bharath;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/servlet1")
public class CookieSessionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Check if the user already has a session
        boolean isNewSession = true;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("sessionId")) {
                    isNewSession = false;
                    break;
                }
            }
        }

        // Create or retrieve the session ID
        String sessionId;
        if (isNewSession) {
            // Generate a new session ID
            sessionId = java.util.UUID.randomUUID().toString();

            // Set the session ID in a cookie
            Cookie sessionCookie = new Cookie("sessionId", sessionId);
            sessionCookie.setMaxAge(60 * 60 * 24 * 7); // Cookie will persist for 1 week
            response.addCookie(sessionCookie);
        } else {
            // Retrieve the session ID from the existing cookie
            sessionId = getSessionIdFromCookie(cookies);
        }

        // Set the response content type
        response.setContentType("text/html");

        // Write the session ID in the response
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Session ID: " + sessionId + "</h2>");
        out.println("</body></html>");
    }

    private String getSessionIdFromCookie(Cookie[] cookies) {
        for (Cookie cookie : cookies) {
            if (cookie.getName().equals("sessionId")) {
                return cookie.getValue();
            }
        }
        return null;
    }
}