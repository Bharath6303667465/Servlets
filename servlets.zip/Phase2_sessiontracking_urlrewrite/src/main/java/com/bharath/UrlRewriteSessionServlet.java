package com.bharath;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/servlet1")
public class UrlRewriteSessionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Check if the session ID is already present in the URL
        String sessionId = request.getParameter("sessionId");

        if (sessionId == null || sessionId.isEmpty()) {
            // Generate a new session ID
            sessionId = java.util.UUID.randomUUID().toString();

            // Append the session ID to the URL using URL rewriting
            String urlWithSessionId = response.encodeRedirectURL(request.getContextPath() + "/servlet1?sessionId=" + sessionId);
            response.sendRedirect(urlWithSessionId);
        }

        // Set the response content type
        response.setContentType("text/html");

        // Write the session ID in the response
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Session ID: " + sessionId + "</h2>");
        out.println("</body></html>");
    }
}